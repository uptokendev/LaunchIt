// Single feature flag for all launchpad-related mock data
export const USE_MOCK_DATA =
  import.meta.env.VITE_USE_MOCK_DATA === "true";