const { expect } = require("chai");
const { ethers } = require("hardhat");

/**
 * LaunchToken sanity checks.
 *
 * The updated architecture deploys LaunchToken from within LaunchCampaign.
 * This suite verifies:
 *  - cap == totalSupply minted
 *  - minted supply is owned by the campaign at deployment
 */

describe("LaunchToken", function () {
  it("mints the full cap to the campaign", async () => {
    const [owner] = await ethers.getSigners();

    const MockRouter = await ethers.getContractFactory("MockRouter");
    const router = await MockRouter.deploy(owner.address, owner.address);
    await router.waitForDeployment();

    const LaunchFactory = await ethers.getContractFactory("LaunchFactory");
    const factory = await LaunchFactory.deploy(await router.getAddress(), owner.address, 1n, 0n);
    await factory.waitForDeployment();

    // Keep the numbers small for test determinism.
    const totalSupply = 1_000n * 10n ** 18n;
    await (await factory.setConfig({
      totalSupply,
      curveBps: 8_000,
      liquidityTokenBps: 9_000,
      liquidityBps: 8_000,
      protocolFeeBps: 200,
      graduationThresholdWei: ethers.parseEther("1"),
    })).wait();

    const req = {
      name: "TESTER",
      symbol: "TEST",
      logoURI: "ipfs://logo",
      description: "desc",
      website: "",
      xAccount: "",
      telegram: "",
    };

    const tx = await factory.createCampaign(req, 0n);
    const receipt = await tx.wait();

    const parsed = receipt.logs
      .map((l) => {
        try {
          return factory.interface.parseLog(l);
        } catch {
          return null;
        }
      })
      .filter(Boolean)
      .find((e) => e.name === "CampaignCreated");

    expect(parsed).to.not.equal(undefined);
    const campaignAddr = parsed.args.campaign;

    const LaunchCampaign = await ethers.getContractFactory("LaunchCampaign");
    const campaign = LaunchCampaign.attach(campaignAddr);
    const tokenAddr = await campaign.token();

    const LaunchToken = await ethers.getContractFactory("LaunchToken");
    const token = LaunchToken.attach(tokenAddr);

    expect(await token.cap()).to.equal(totalSupply);
    expect(await token.totalSupply()).to.equal(totalSupply);
    expect(await token.balanceOf(campaignAddr)).to.equal(totalSupply);
  });
});
