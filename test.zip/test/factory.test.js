const { expect } = require("chai");
const { ethers } = require("hardhat");

/**
 * LaunchFactory tests aligned to the updated createCampaign flow:
 *  - LaunchFactory deploys LaunchCampaign
 *  - LaunchCampaign deploys LaunchToken and mints totalSupply to itself
 *  - Optional initial buy at creation time (createCampaign(..., initialBuyTokens))
 */

function bn(x) {
  return BigInt(x);
}

async function getCampaignCreated(factory, receipt) {
  for (const log of receipt.logs) {
    try {
      const parsed = factory.interface.parseLog(log);
      if (parsed && parsed.name === "CampaignCreated") return parsed;
    } catch {
      // ignore
    }
  }
  throw new Error("CampaignCreated event not found");
}

describe("LaunchFactory - createCampaign", function () {
  it("creates a campaign, deploys token, and optionally performs an initial buy", async function () {
    const [deployer, creator, feeRecipient] = await ethers.getSigners();

    const MockRouter = await ethers.getContractFactory("MockRouter");
    const router = await MockRouter.deploy(ethers.ZeroAddress, ethers.ZeroAddress);
    await router.waitForDeployment();

    const LaunchFactory = await ethers.getContractFactory("LaunchFactory");
    const basePrice = ethers.parseEther("0.01"); // 0.01 BNB per token
    const slope = 0n;

    const factory = await LaunchFactory.deploy(await router.getAddress(), await feeRecipient.getAddress(), basePrice, slope);
    await factory.waitForDeployment();

    // Small config for test determinism.
    await (await factory.setConfig({
      totalSupply: ethers.parseEther("1000"),
      curveBps: 8000,
      liquidityBps: 8000,
      liquidityTokenBps: 9000,
      protocolFeeBps: 200,
      graduationThresholdWei: ethers.parseEther("1"),
    })).wait();

    const request = {
      name: "Tester",
      symbol: "TEST",
      logoURI: "ipfs://logo",
      website: "https://example.com",
      xAccount: "tester",
    };

    // Initial buy: 10 tokens.
    const initialBuyTokens = ethers.parseEther("10");

    // We need to know how much value to send for the initial buy.
    // The factory will call campaign.quoteBuyExactTokens(...) internally, then add fee.
    // For the first buy, soldTokens=0 so gross = basePrice * amount.
    const gross = (basePrice * bn(initialBuyTokens)) / bn(ethers.parseEther("1"));
    const fee = (gross * 200n) / 10_000n;

    const tx = await factory.connect(creator).createCampaign(request, initialBuyTokens, { value: gross + fee });
    const receipt = await tx.wait();
    const evt = await getCampaignCreated(factory, receipt);

    const campaignAddr = evt.args.campaign;
    const tokenAddr = evt.args.token;

    expect(campaignAddr).to.properAddress;
    expect(tokenAddr).to.properAddress;

    const campaign = await ethers.getContractAt("LaunchCampaign", campaignAddr);
    expect(await campaign.creator()).to.equal(await creator.getAddress());
    expect(await campaign.token()).to.equal(tokenAddr);

    // Creator received the initial buy tokens.
    const token = await ethers.getContractAt("LaunchToken", tokenAddr);
    const creatorBal = await token.balanceOf(await creator.getAddress());
    expect(creatorBal).to.equal(initialBuyTokens);

    // Campaign holds the remaining supply.
    const totalSupply = await token.totalSupply();
    const campaignBal = await token.balanceOf(campaignAddr);
    expect(creatorBal + campaignBal).to.equal(totalSupply);
  });
});
