const { expect } = require("chai");
const { ethers, network } = require("hardhat");

/**
 * Updated bonding-curve tests for the current LaunchFactory/LaunchCampaign design.
 *
 * Key invariants we test:
 *  - Buy fee: buyer pays (gross + fee) and feeRecipient receives fee (in BNB).
 *  - Sell fee: seller receives (gross - fee) and feeRecipient receives fee (in BNB).
 *  - Finalize fee: feeRecipient receives 2% of the *BNB balance raised* right before LP.
 *  - Post-finalize: curve trading is disabled (reverts on buy/sell).
 */

function bpsMul(amountWei, bps) {
  return (amountWei * BigInt(bps)) / 10_000n;
}

async function getBalance(addr) {
  return await ethers.provider.getBalance(addr);
}

async function getGasCost(tx) {
  const r = await tx.wait();
  return BigInt(r.gasUsed) * BigInt(r.effectiveGasPrice);
}

async function deployFixture() {
  const [deployer, feeRecipient, creator, buyer] = await ethers.getSigners();

  // Minimal router mock (doesn't need a real factory/WETH for our tests)
  const MockRouter = await ethers.getContractFactory("MockRouter");
  const router = await MockRouter.deploy(ethers.ZeroAddress, ethers.ZeroAddress);
  await router.waitForDeployment();

  // Deploy factory with a simple, flat curve (slope = 0)
  const LaunchFactory = await ethers.getContractFactory("LaunchFactory");
  const basePrice = ethers.parseEther("0.01"); // 0.01 BNB per token
  const slope = 0n;
  const factory = await LaunchFactory.deploy(await router.getAddress(), await feeRecipient.getAddress(), basePrice, slope);
  await factory.waitForDeployment();

  // Tight config so we can hit graduation cheaply in unit tests
  const cfg = {
    totalSupply: 1_000n * 10n ** 18n, // 1,000 tokens
    curveBps: 5_000,                 // 50% sold on curve
    liquidityBps: 8_000,             // 80% of raised BNB goes to LP (=> 20% creator)
    liquidityTokenBps: 9_000,        // 90% of non-curve tokens go to LP
    graduationThresholdWei: ethers.parseEther("1"),
    protocolFeeBps: 200,             // 2%
  };
  await (await factory.setConfig(cfg)).wait();

  // Create a campaign (no initial buy in this fixture)
  const req = {
    name: "Tester",
    symbol: "TEST",
    description: "unit test",
    logoURI: "ipfs://logo",
    website: "",
    xAccount: "",
    telegram: "",
    initialBuyTokens: 0n,
  };

  const tx = await factory.connect(creator).createCampaign(req, { value: 0n });
  const receipt = await tx.wait();
  const parsed = receipt.logs
    .map((l) => {
      try {
        return factory.interface.parseLog(l);
      } catch {
        return null;
      }
    })
    .filter(Boolean);

  const created = parsed.find((e) => e.name === "CampaignCreated");
  expect(created, "CampaignCreated event not found").to.not.equal(undefined);

  const campaignAddr = created.args.campaign;
  const tokenAddr = created.args.token;

  const campaign = await ethers.getContractAt("LaunchCampaign", campaignAddr);
  const token = await ethers.getContractAt("LaunchToken", tokenAddr);

  return { deployer, feeRecipient, creator, buyer, router, factory, campaign, token, cfg };
}

describe("LaunchCampaign (bonding curve)", function () {
  it("charges 2% fee on buy (paid in BNB to feeRecipient)", async function () {
    const { feeRecipient, buyer, campaign, token, cfg } = await deployFixture();

    const amount = 10n * 10n ** 18n; // 10 tokens
    const gross = await campaign.quoteBuyExactTokens(amount);
    const fee = bpsMul(gross, cfg.protocolFeeBps);

    const feeBefore = await getBalance(await feeRecipient.getAddress());
    const campBefore = await getBalance(await campaign.getAddress());

    await (await campaign.connect(buyer).buyExactTokens(amount, { value: gross + fee })).wait();

    const feeAfter = await getBalance(await feeRecipient.getAddress());
    const campAfter = await getBalance(await campaign.getAddress());

    expect(feeAfter - feeBefore).to.equal(fee);
    expect(campAfter - campBefore).to.equal(gross);

    const buyerTokens = await token.balanceOf(await buyer.getAddress());
    expect(buyerTokens).to.equal(amount);
  });

  it("charges 2% fee on sell (paid in BNB to feeRecipient)", async function () {
    const { feeRecipient, buyer, campaign, token, cfg } = await deployFixture();

    const buyAmt = 10n * 10n ** 18n;
    const grossBuy = await campaign.quoteBuyExactTokens(buyAmt);
    const buyFee = bpsMul(grossBuy, cfg.protocolFeeBps);
    await (await campaign.connect(buyer).buyExactTokens(buyAmt, { value: grossBuy + buyFee })).wait();

    const sellAmt = 4n * 10n ** 18n;
    await (await token.connect(buyer).approve(await campaign.getAddress(), sellAmt)).wait();

    const grossSell = await campaign.quoteSellExactTokens(sellAmt);
    const sellFee = bpsMul(grossSell, cfg.protocolFeeBps);
    const expectedNet = grossSell - sellFee;

    const feeBefore = await getBalance(await feeRecipient.getAddress());
    const buyerBefore = await getBalance(await buyer.getAddress());

    const tx = await campaign.connect(buyer).sellExactTokens(sellAmt);
    const gas = await getGasCost(tx);

    const feeAfter = await getBalance(await feeRecipient.getAddress());
    const buyerAfter = await getBalance(await buyer.getAddress());

    expect(feeAfter - feeBefore).to.equal(sellFee);

    // buyerAfter = buyerBefore + expectedNet - gas
    expect(buyerAfter - buyerBefore + gas).to.equal(expectedNet);
  });

  it("takes a 2% finalize fee from the raised BNB, then allocates LP and creator payout", async function () {
    const { feeRecipient, creator, buyer, factory, campaign, cfg } = await deployFixture();

    // Buy enough tokens to reach the graduation threshold (in BNB) in this simplified curve (slope=0)
    // Since basePrice is 0.01 BNB/token, buying 100 tokens yields gross 1 BNB.
    const amount = 100n * 10n ** 18n;
    const gross = await campaign.quoteBuyExactTokens(amount);
    expect(gross).to.equal(cfg.graduationThresholdWei);

    const fee = bpsMul(gross, cfg.protocolFeeBps);
    await (await campaign.connect(buyer).buyExactTokens(amount, { value: gross + fee })).wait();

    // At this point, campaign balance == gross (fees have been siphoned to feeRecipient).
    const raisedBeforeFinalize = await getBalance(await campaign.getAddress());
    expect(raisedBeforeFinalize).to.equal(gross);

    // Impersonate the factory contract (campaign owner) to call finalize.
    const factoryAddr = await factory.getAddress();
    await network.provider.request({
      method: "hardhat_impersonateAccount",
      params: [factoryAddr],
    });
    await network.provider.request({
      method: "hardhat_setBalance",
      params: [factoryAddr, "0x1000000000000000000"], // plenty for gas
    });
    const factorySigner = await ethers.getSigner(factoryAddr);

    const feeBefore = await getBalance(await feeRecipient.getAddress());
    const creatorBefore = await getBalance(await creator.getAddress());

    const finTx = await campaign.connect(factorySigner).finalize({ gasLimit: 5_000_000 });
    await finTx.wait();

    const feeAfter = await getBalance(await feeRecipient.getAddress());
    const creatorAfter = await getBalance(await creator.getAddress());

    const finalizeFee = bpsMul(raisedBeforeFinalize, cfg.protocolFeeBps);
    const remainingAfterFee = raisedBeforeFinalize - finalizeFee;
    const expectedLpValue = bpsMul(remainingAfterFee, cfg.liquidityBps);
    const expectedCreator = remainingAfterFee - expectedLpValue; // remainder goes to creator in current design

    expect(feeAfter - feeBefore).to.equal(finalizeFee);
    expect(creatorAfter - creatorBefore).to.equal(expectedCreator);

    // Post-finalize: curve trading must be disabled.
    await expect(
      campaign.connect(buyer).buyExactTokens(1n * 10n ** 18n, { value: ethers.parseEther("0.02") })
    ).to.be.revertedWith("launched");

    await network.provider.request({
      method: "hardhat_stopImpersonatingAccount",
      params: [factoryAddr],
    });
  });
});
