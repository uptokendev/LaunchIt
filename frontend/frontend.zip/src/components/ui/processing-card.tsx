/**
 * Processing Card Component (Legacy Export)
 * Re-exports the refactored ProcessingCard component for backwards compatibility
 */

export { default } from "./processing-card-refactored";
